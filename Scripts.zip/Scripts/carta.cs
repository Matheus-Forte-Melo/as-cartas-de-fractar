[System.Serializable]
public class Carta
{
    public string nome;
    public int custo;
    public int poder;
}
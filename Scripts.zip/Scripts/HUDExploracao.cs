using UnityEngine;
using TMPro;

public class HUDExploracao : MonoBehavior
{
    [Header("Container Principal")]
    [Tooltip("Coloque aqui o painel que segura o HUD. Também um comando para desligar na hora da batalha")]
    public GameObject painelHUDPrincipal;

    [Header("Textos do HUD (Informações Rápidas)")]
    public TextMeshProUGUI textoVida;
    public TextMeshProUGUI textoMoedas;
    public TextMeshProUGUI textoAndar;
    public TextMeshProUGUI textoTamanhoDeck;

    [Header("Pop-ups")]
    public GameObject telaInventario;
    public GameObject telaMapa;
    public GameObject telaAnotacoes;
    public GameObject telaConfiguracoes;

    private void Start()
    {
        MostrarHUD();
        FecharTodasTelasSobrepostas();
    }

    //Mostra o HUD
    public void MostrarHUD()
    {
        painelHUDPrincipal.SetActive(true);
    }

    public void EsconderHUDParaBatalha()
    {
        painelHUDPrincipal.SetActive(false);
        FecharTodasTelasSobrepostas();
    }

    //Atualiza os dados do jogador
    public void AtualizarStatus(int vidaAtual, int vidaMax, int moedas, int andarAtual, int cartasNoDeck)
    {
        textoVida.text = vidaAtual + " / " + vidaMax;
        textoMoedas.text = moedas.ToString();
        textoAndar.text = "Andar: " + andarAtual;
        textoTamanhoDeck.text = cartasNoDeck.ToString();
    }

    //Botoes
    public void AlternarMapa()
    {
        bool estadoAtual = telaMapa.activeSelf;
        FecharTodasTelasSobrepostas();
        telaMapa.SetActive(!estadoAtual);
    }

    public void AlternarInventario()
    {
        bool estadoAtual = telaInventario.activeSelf;
        FecharTodasTelasSobrepostas();
        telaInventario.SetActive(!estadoAtual);
    }

        public void AlternarAnotacoes()
    {
        bool estadoAtual = telaAnotacoes.activeSelf;
        FecharTodasTelasSobrepostas();
        telaAnotacoes.SetActive(!estadoAtual);
    }

        public void AlternarConfiguracoes()
    {
        bool estadoAtual = tela.activeSelf;
        FecharTodasTelasSobrepostas();
        telaConfiguracoes.SetActive(!estadoAtual);
    }

    private void FecharTodasTelasSobrepostas()
    {
        telaMapa.SetActive(false);
        telaInventario.SetActive(false);
        telaAnotacoes.SetActive(false);
        telaConfiguracoes.SetActive(false);
    }

}
using System.Collections.Generic;
using UnityEngine;

public class GerenciadorDeMao : MonoBehavior
{
    //Lista de cartas na mão
    public List<Carta> maoDoJogador = new List<Carta>();

    void Start()
    {
        //Carta exemplo ao iniciar o jogo
        AdicionarCartaARecife("Às de espadas",1,1);
    }

    public void AdicionarCartaARecife(string nomeCarta, int custoCarta, int poderCarta)
    {
        //Instância da classe Carta
        Carta novaCarta = new Carta();
        novaCarta.nome = nomeCarta;
        novaCarta.custo = custoCarta;
        novaCarta.poder = poderCarta;

        //Adicionar a instância à lista
        maoDoJogador.Add(novaCarta);

        Debug.Log("Adicionada: " + novaCarta.nome + " à sua mão");
    }
}
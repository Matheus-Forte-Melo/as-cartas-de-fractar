using UnityEngine;

public class HudManager : MonoBehavior
{
    [Header("Telas do Jogo (Arraste os painéis do Unity aqui)")]
    public GameObject painelMenuPrincipal;
    public GameObject painelItens;
    public GameObject painelMapa;
    public GameObject painelConfiguracoes;

    private void Awake()
    {
        //garante que o objeto não seja destruído (nem o HUD) se outra cena carregar
        DontDestroyOnLoad(this.gameObject);
    }

    private void Start()
    {
        //garante que apenas o menu principal aparece quando começa o jogo
        AbrirMenuPrincipal();
    }

    //BOTÕES:
    //Ligar cada função abaixo no evento "OnClick" na Unity (cada um no seu botão)
    public void AbrirMenuPrincipal()
    {
        EsconderTodasAsTelas();
        painelMenuPrincipal.SetActive(true);
    }

    public void AbrirMenuDeItens()
    {
        EsconderTodasAsTelas();
        painelItens.SetActive(true);
    }

    public void AbrirLoja()
    {
        EsconderTodasAsTelas();
        painelLoja.SetActive(true);
    }

    public void AbrirConfiguracoes()
    {
        EsconderTodasAsTelas();
        painelConfiguracoes.SetActive(true);
    }

    //Auxiliar para desligar as telas e não ter sobreposições
    private void EsconderTodasAsTelas()
    {
        painelMenuPrincipal.SetActive(false);
        painelItens.SetActive(false);
        painelLoja.SetActive(false);
        painelMapa.SetActive(false);
        painelConfiguracoes.SetActive(false);
    }
}